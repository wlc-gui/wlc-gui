function authenticate() {
    Swal.fire({
      title: 'PSK_Authentication',
      html: '<input id="name" class="swal2-input" placeholder="이름을 입력하세요.">',
      confirmButtonText: '다음',
      showCancelButton: true,
      cancelButtonText: '취소',
      preConfirm: function () {
        var name = document.getElementById('name').value;
        return name;
      }
    }).then(function (result) {
      if (!result.dismiss) {
        var name = result.value;
        Swal.fire({
          title: `${name}님`,
          html: '<input id="password" type="password" class="swal2-input" placeholder="Enter the Shared Key">',
          confirmButtonText: '확인',
          showCancelButton: true,
          cancelButtonText: '취소',
          preConfirm: function () {
            var password = document.getElementById('password').value;
            return password;
          }
        }).then(function (result) {
          if (!result.dismiss) {
            var password = result.value;
            if (password === 't2e0am2log3') {
              Swal.fire('Authentication Success!', '', 'success');
            } else {
              Swal.fire('Wrong Key!!', '', 'error');
            }
          }
        });
      }
    });
  }